/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador;

import Modelo.Alimentos;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author usuario
 */
public class AlimentosController implements Initializable {

    @FXML
    private TableView<Alimentos> tabla;
    @FXML
    private TableColumn<?, ?> Tproducto;
    @FXML
    private TableColumn<?, ?> TCantidad;
    @FXML
    private TableColumn<?, ?> TCaducidad;
    @FXML
    private Label volverInicio;
    @FXML
    private TextField nombre;
    @FXML
    private TextField cantidad;
    @FXML
    private TextField caducidad;
    
    private ObservableList<Alimentos> galimentos;
    @FXML
    private Button modificar;
    @FXML
    private Button eliminar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        galimentos = FXCollections.observableArrayList();
        
        Tproducto.setCellValueFactory(new PropertyValueFactory("producto"));
        TCantidad.setCellValueFactory(new PropertyValueFactory("cantidad"));
        TCaducidad.setCellValueFactory(new PropertyValueFactory("caducidad"));
    }    

    @FXML
    private void volverInicio(MouseEvent event) {
        Stage escPrin = (Stage) volverInicio.getScene().getWindow();
           
           Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("/Vistas/Inicio.fxml"));
            Scene scene = new Scene(root);
            
            escPrin.setTitle("Inicio");
            // Seteo la scene y la muestro
            escPrin.setScene(scene);
            escPrin.show();
        } catch (IOException ex) {
            System.getLogger(InicioController.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
    }

    @FXML
    private void seleccionarP(MouseEvent event) {
            Alimentos aux = tabla.getSelectionModel().getSelectedItem();
        
        if(aux!=null){
            nombre.setText(aux.getNombre());
            cantidad.setText(aux.getCantidad());
            caducidad.setText(aux.getCaducidad()+"");
        }
    }

    @FXML
    private void subirP(MouseEvent event) {
        String nombreP = nombre.getText();
        String cantidadP = cantidad.getText();
        String caducidadP = caducidad.getText();
        
        Alimentos elemento = new Alimentos(nombreP,cantidadP,caducidadP);
        
        galimentos.add(elemento);
        tabla.setItems(galimentos);
    }

    @FXML
    private void modificarP(MouseEvent event) {
        Alimentos copia = tabla.getSelectionModel().getSelectedItem();
        
        if(copia == null) {
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("ERROR");
            alerta.setContentText("El producto seleccionado no existe en la tabla");
            alerta.showAndWait();
        }
        else {
            String nombreP = nombre.getText();
            String cantidadP = cantidad.getText();
            String caducidadP = caducidad.getText();
            
            Alimentos elemento = new Alimentos(nombreP,cantidadP,caducidadP);
            
            if(!galimentos.contains(elemento)) {
                copia.setNombre(nombreP);
                copia.setCantidad(cantidadP);
                copia.setCaducidad(caducidadP);
                
                tabla.refresh();
            }
        }
    }

    @FXML
    private void eliminarP(MouseEvent event) {
         Alimentos copia = tabla.getSelectionModel().getSelectedItem();
        
        if(copia==null){
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("Error");
            alerta.setContentText("El alimento seleccionado no existe en la tabla");
            alerta.showAndWait();
        }else{
            galimentos.remove(copia);
            tabla.refresh();
        }
    }
}
